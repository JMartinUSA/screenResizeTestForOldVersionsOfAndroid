var windowHeight = window.innerHeight;

function onload(){
	document.getElementById("container").style.height=windowHeight+"px";
	alert("Window Height: "+windowHeight)
}